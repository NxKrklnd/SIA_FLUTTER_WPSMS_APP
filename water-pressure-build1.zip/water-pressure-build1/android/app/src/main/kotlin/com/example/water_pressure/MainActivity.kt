package com.example.water_pressure

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
